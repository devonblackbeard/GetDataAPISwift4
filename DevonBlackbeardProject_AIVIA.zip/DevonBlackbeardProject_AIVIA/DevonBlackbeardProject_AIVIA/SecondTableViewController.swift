//
//  SecondTableViewController.swift
//  DevonBlackbeardProject_AIVIA
//
//  Created by Devon Blackbeard on 2020-01-18.
//  Copyright © 2020 Devon Blackbeard. All rights reserved.
//

import UIKit

class SecondTableViewController: UITableViewController
{
    // Hold the Keys
    var KeyArray = [String]()
    
    // Hold the Properties
    var PropertyArray = [String]()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let Cell = self.tableView.dequeueReusableCell(withIdentifier: "secondCell", for: indexPath) as UITableViewCell
        
        Cell.textLabel?.text = KeyArray[indexPath.row]
        Cell.detailTextLabel?.text = PropertyArray[indexPath.row]
        
        return Cell
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return KeyArray.count
    }
    

}
