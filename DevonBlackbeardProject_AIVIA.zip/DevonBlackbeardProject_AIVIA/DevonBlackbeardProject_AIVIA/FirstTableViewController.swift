//
//  FirstViewController.swift
//  DevonBlackbeardProject_AIVIA
//
//  Created by Devon Blackbeard on 2020-01-18.
//  Copyright © 2020 Devon Blackbeard. All rights reserved.
//
import Foundation
import UIKit

class FirstTableViewController: UITableViewController
{
    var FirstTableArray = [String]()
     var Fields = [String](arrayLiteral: "Name", "Secret Identity", "Group Alliance", "Place of Origin", "Company")
        

    override func viewDidLoad()
    {
        // Do any additional setup after loading the view.
        super.viewDidLoad()
        downloadJsonData()
    }
    
    // URL for API GET
    final let url = URL(string: "https://ios-prod.aivia.dev/api/production/heros")
    // Make a variable which is an array of heroes
    private var heroes = [Hero]()


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return heroes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        
        // populate cell with hero names. Drill-down for more info.
        cell.textLabel?.text = heroes[indexPath.row].name
        
        ///
//        if(cell == nil)
//        {
//            cell = UITableViewCell(style:UITableViewCell.CellStyle.value1, reuseIdentifier: "Cell")
//        }
        
        let image = UIImage(named: "star")
        cell.imageView?.image = image
        let highlightedImage = UIImage(named: "star2")
        cell.imageView?.highlightedImage = highlightedImage
        
        // This data is just for show
        if indexPath.row < 7
        {
            cell.detailTextLabel?.text = "DC"
        }
        else
        {
            cell.detailTextLabel?.text = "MARVEL"
        }
        cell.textLabel?.text = heroes[indexPath.row].name
    
        return cell
    }
    
    
    // Called on page load
    func downloadJsonData()
    {
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL)
        {
            data, urlResponse, error in
            
            guard let data = data, error == nil, urlResponse != nil else
            {
                print("Error retrieving data")
                return
            }
            print("Downloaded")
            do
            {
                let decoder = JSONDecoder()
                // Download the data from the API
                let downloadedHeroes = try decoder.decode(HeroPage.self, from: data)
                
                // Assign array of heroes to local heroes variable
                self.heroes = downloadedHeroes.data
                
                // Must switch to main thread, cannot update table on a background thread
                // UI Updates only done on Main Thread
                DispatchQueue.main.async
                {
                    self.tableView.reloadData()
                }
            }
            catch
            {
                print("Problem with download")
            }
            
        }.resume()
    }
    
    // When a certain row is tapped
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let rowName = heroes[indexPath.row].name
        let rowIdentity = heroes[indexPath.row].identity
        let message = "Name: \(rowName) " + "\nIdentity: " + rowIdentity
        
        
        let alert = UIAlertController(title: "Hero Selected:", message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "View More", style: .default, handler: {action in
            self.performSegue(withIdentifier: "secondCell", sender: self)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {action in
            self.view.layoutIfNeeded()}
            
        ))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if(segue.identifier == "secondCell")
        {
            
        print("id is secnodCell")
        let row = self.tableView?.indexPathForSelectedRow?.row ?? 0
        let SecondViewController = segue.destination as! SecondTableViewController

        // Keys
        SecondViewController.KeyArray = Fields

        // Values
        let name = heroes[row].name
        let identity = heroes[row].identity
        let alliance = heroes[row].group
        let origin = heroes[row].place_of_origin
        let country = heroes[row].publisher

        SecondViewController.PropertyArray = [name, identity, alliance, origin, country]
        }

    }

    func shouldPerformSegueWithIdentifier(identifier: String!, sender: AnyObject!) -> Bool
    {
//        let row = self.tableView?.indexPathForSelectedRow?.row ?? 0
//                let SecondViewController = segue.destination as! SecondTableViewController
//
//                // Keys
//                SecondViewController.KeyArray = Fields
//
//                // Values
//                let name = heroes[row].name
//                let identity = heroes[row].identity
//                let alliance = heroes[row].group
//                let origin = heroes[row].place_of_origin
//                let country = heroes[row].publisher
//
//                SecondViewController.PropertyArray = [name, identity, alliance, origin, country]

        return false
    }
    
 





}
