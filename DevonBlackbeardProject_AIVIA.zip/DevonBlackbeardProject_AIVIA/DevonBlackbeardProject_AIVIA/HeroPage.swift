//
//  HomePage.swift
//  DevonBlackbeardProject_AIVIA
//
//  Created by Devon Blackbeard on 2020-01-18.
//  Copyright © 2020 Devon Blackbeard. All rights reserved.
//


// Model for the API Hero Data ...

import Foundation


struct HeroPage: Decodable
{
    let data: [Hero]
}

struct Hero: Decodable{
    let id: Int
    let name: String
    let identity: String
    let group: String
    let place_of_origin: String
    let publisher: String
}

